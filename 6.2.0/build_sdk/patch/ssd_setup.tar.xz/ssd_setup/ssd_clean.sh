#!/bin/bash


set -e



if [ -z "$1" ]
  then
    echo "No Password"
    echo "ex) ./ssd_clean password"
    exit 1
fi


SUPWD=$1

NVMECOUNT=`lsblk | grep nvme | wc -l`
echo "nvme blk# $NVMECOUNT"

if [ $NVMECOUNT -lt 1 ]; then
	echo "ERROR: nvme ssd not detected"
	exit 1
fi

echo "START Setup" 

dev_list=()

for NVME_C in /sys/class/nvme/*; 
do
	for NVME_B in $NVME_C/*;
	do
		if ! [ -L "$NVME_B" ] && [ -d "$NVME_B" ] && [ -f "$NVME_B/uevent" ]; then
			NVME_B_DEVNAME=`cat "$NVME_B/uevent" | grep "DEVNAME=" | awk -F= '{ print $2 }'`
			NVME_B_DEVPATH="/dev/$NVME_B_DEVNAME"
			if [ -b "$NVME_B_DEVPATH" ]; then
				echo "found block device at $NVME_B_DEVPATH"
				dev_list+=($NVME_B_DEVPATH)
			fi
		fi
	done

done


#double check
if ! [[ ${dev_list[@]} ]]; then
	echo "ERROR: nvme ssd not found"
	exit 1
fi


BLKDEV="${dev_list[0]}"

echo "checking $BLKDEV..."

PARTDEV=$BLKDEV"p1"
MOUNTED=`mount | grep $PARTDEV | wc -l`
if [ $MOUNTED == 1 ]; then
	#unmount first
	echo "unmount already mounted path"
	echo "$SUPWD" | sudo -S umount -f $PARTDEV
	if [ $? -ne 0 ]; then
		echo "ERROR: unmount $PARTDEV failed"
		exit 1
	fi
fi


echo "clear partition tables..."
   	echo "$SUPWD" | sudo -S sgdisk --clear $BLKDEV
    
    
echo "# Format SSD"
sudo /sbin/parted  /dev/nvme0n1 mklabel gpt --script
echo "# Make workspace"
sudo /sbin/parted  /dev/nvme0n1 mkpart workspace 0 100% --script
sync
echo "# Make filesystem"
yes | sudo mkfs.ext4 /dev/nvme0n1p1
sync      



    