#!/bin/bash


set -e


if [ -z "$1" ]
  then
    echo "ex) ./copy_from_host.sh robotis@1.1.1.1  /home/robotis/images.tar.gz"
    exit 1
fi

Host=$1
File=$2

echo "Host = $Host"
echo "File = $File"

sudo ssh ${Host} cat ${File} | sudo tar --checkpoint=.1000 --same-owner -zxf -
sync



    