#!/bin/bash


set -e

device_ssd="/dev/nvme0n1p1"
device_mmc="/dev/mmcblk0p1"


function is_mounted 
{
    mount | awk -v DIR="$1" '{if ($3 == DIR) { exit 0}} ENDFILE{exit -1}'
}


if [ ! -d "/mnt" ]; then
  sudo mkdir /mnt
fi 


if mountpoint -q /mnt; then
  sudo umount /mnt
fi



if mountpoint=$(findmnt -nr -o target -S "$device_mmc"); then
  echo "sudo sed -i 's/root=\/dev\/nvme0n1p1/root=\/dev\/mmcblk0p1/g' /boot/extlinux/extlinux.conf"
  sudo sed -i 's/root=\/dev\/nvme0n1p1/root=\/dev\/mmcblk0p1/g' /boot/extlinux/extlinux.conf
  sync
else
  sudo mount $device_mmc /mnt
  echo "sudo sed -i 's/root=\/dev\/nvme0n1p1/root=\/dev\/mmcblk0p1/g' /mnt/boot/extlinux/extlinux.conf"
  sudo sed -i 's/root=\/dev\/nvme0n1p1/root=\/dev\/mmcblk0p1/g' /mnt/boot/extlinux/extlinux.conf
  sync  
fi  


echo "run 'sudo reboot'"


    